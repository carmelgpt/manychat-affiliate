# Manychat Affiliate Link

A Pen created on CodePen.io. Original URL: [https://codepen.io/Carmel-Navarro-/pen/jOgvBeM](https://codepen.io/Carmel-Navarro-/pen/jOgvBeM).

