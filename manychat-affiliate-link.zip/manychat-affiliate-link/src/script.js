document.getElementById('copyButton').addEventListener('click', function() {
    const linkInput = document.getElementById('linkInput');
    linkInput.select();
    document.execCommand('copy');
    alert('Link copied to clipboard!');
});
